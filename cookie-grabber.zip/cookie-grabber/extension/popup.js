// popup.js

const DEFAULT_WS = 'wss://workspacej9jjy0b2zdgg0ebafo-8081.gz.cloudide.woa.com';

const $ = (id) => document.getElementById(id);

let currentStatus = null;

// ─── UI 状态切换 ──────────────────────────────────────────────────────────────

function showState(state) {
  $('idle-state').classList.add('hidden');
  $('request-state').classList.add('hidden');
  $('grab-state').classList.add('hidden');

  if (state === 'idle') $('idle-state').classList.remove('hidden');
  if (state === 'request') $('request-state').classList.remove('hidden');
  if (state === 'grab') $('grab-state').classList.remove('hidden');
}

function updateStatusBar(connected) {
  const dot = $('ws-dot');
  const text = $('ws-status-text');
  if (connected) {
    dot.className = 'dot green';
    text.textContent = '已连接';
  } else {
    dot.className = 'dot red';
    text.textContent = '未连接';
  }
}

// ─── 刷新状态 ────────────────────────────────────────────────────────────────

function refresh() {
  chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (status) => {
    currentStatus = status;

    updateStatusBar(status.connected);

    // 预填 WS 地址
    if (status.wsUrl) {
      $('ws-url').value = status.wsUrl;
    } else {
      $('ws-url').value = DEFAULT_WS;
    }

    if (status.activeGrab) {
      showState('grab');
      $('grab-url').textContent = status.activeGrab.targetUrl;
    } else if (status.pendingRequest) {
      showState('request');
      $('req-url').textContent = status.pendingRequest.targetUrl;
      $('req-reason').textContent = status.pendingRequest.reason || '开发工具请求获取该网站的登录态 Cookie。';
    } else {
      showState('idle');
    }
  });
}

// ─── 按钮事件 ────────────────────────────────────────────────────────────────

$('btn-connect').addEventListener('click', () => {
  const url = $('ws-url').value.trim();
  if (!url) return;
  chrome.runtime.sendMessage({ type: 'CONNECT_WS', url }, (res) => {
    if (res && res.ok) {
      setTimeout(refresh, 500);
    } else {
      alert('连接失败：' + (res && res.error || '未知错误'));
    }
  });
});

$('btn-approve').addEventListener('click', () => {
  if (!currentStatus || !currentStatus.pendingRequest) return;
  const { requestId, targetUrl } = currentStatus.pendingRequest;
  chrome.runtime.sendMessage({
    type: 'USER_DECISION',
    approved: true,
    requestId,
    targetUrl
  }, () => setTimeout(refresh, 300));
});

$('btn-deny').addEventListener('click', () => {
  if (!currentStatus || !currentStatus.pendingRequest) return;
  const { requestId } = currentStatus.pendingRequest;
  chrome.runtime.sendMessage({
    type: 'USER_DECISION',
    approved: false,
    requestId
  }, () => setTimeout(refresh, 300));
});

$('btn-submit').addEventListener('click', () => {
  $('btn-submit').disabled = true;
  $('btn-submit').textContent = '⏳ 收集中…';
  chrome.runtime.sendMessage({ type: 'SUBMIT_COOKIE' }, (res) => {
    if (res && res.ok) {
      $('btn-submit').textContent = `✅ 已发送 ${res.cookieCount || ''} 个来源的 Cookie`;
      setTimeout(() => window.close(), 1500);
    } else {
      $('btn-submit').textContent = '❌ 失败：' + (res && res.error || '未知');
      $('btn-submit').disabled = false;
    }
  });
});

$('btn-cancel').addEventListener('click', () => {
  if (!currentStatus || !currentStatus.activeGrab) return;
  chrome.runtime.sendMessage({
    type: 'USER_DECISION',
    approved: false,
    requestId: currentStatus.activeGrab.requestId
  }, () => setTimeout(refresh, 300));
});

// ─── 回车连接 ────────────────────────────────────────────────────────────────
$('ws-url').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('btn-connect').click();
});

// ─── 初始化 ──────────────────────────────────────────────────────────────────
refresh();
// 每 2 秒刷新一次状态（处理外部触发）
setInterval(refresh, 2000);
