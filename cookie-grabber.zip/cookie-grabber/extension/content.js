// content.js
// 注入到所有页面，但只在 background 主动调用时才执行操作
// 这里目前为空 — cookie 收集通过 chrome.scripting.executeScript 动态注入
// 保留此文件用于未来扩展（比如检测登录状态变化等）

// 监听来自 background 的消息
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'PING_CONTENT') {
    sendResponse({ alive: true, url: location.href });
  }
});
