// background.js - Service Worker
// 只接受来自 cloudide.woa.com 的 WebSocket 服务端

const ALLOWED_WS_ORIGINS = [
  'wss://workspacej9jjy0b2zdgg0ebafo-8081.gz.cloudide.woa.com'
];

let ws = null;
let pendingRequest = null; // { requestId, targetUrl, resolve }

// ─── WebSocket 连接管理 ───────────────────────────────────────────────────────

function connectWS(wsUrl) {
  if (ws && ws.readyState === WebSocket.OPEN) return;

  ws = new WebSocket(wsUrl);

  ws.onopen = () => {
    console.log('[CookieBridge] WS connected:', wsUrl);
    chrome.action.setBadgeText({ text: '✓' });
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
  };

  ws.onmessage = async (event) => {
    let msg;
    try { msg = JSON.parse(event.data); } catch { return; }

    // 服务端发来的登录态请求
    if (msg.type === 'REQUEST_COOKIE') {
      const { requestId, targetUrl, reason } = msg;
      // 存储待处理请求
      pendingRequest = { requestId, targetUrl, reason };
      await chrome.storage.session.set({ pendingRequest });

      // 通知 popup 弹出（打开 badge）
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });

      // 尝试打开 popup（仅在用户关注时有效，备用方案是用 notification）
      // 主要靠 badge 吸引用户点击
    }

    if (msg.type === 'PING') {
      ws.send(JSON.stringify({ type: 'PONG' }));
    }
  };

  ws.onclose = () => {
    console.log('[CookieBridge] WS disconnected, retrying in 3s...');
    chrome.action.setBadgeText({ text: '' });
    ws = null;
    setTimeout(() => connectWS(wsUrl), 3000);
  };

  ws.onerror = (err) => {
    console.error('[CookieBridge] WS error', err);
  };
}

// ─── 消息处理（来自 popup / content script）──────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // popup 告知用户同意/拒绝
  if (msg.type === 'USER_DECISION') {
    const { approved, requestId, targetUrl } = msg;

    if (!approved) {
      // 拒绝
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'COOKIE_DENIED', requestId }));
      }
      chrome.action.setBadgeText({ text: '' });
      sendResponse({ ok: true });
      return true;
    }

    // 同意：打开目标网站，等用户登录后点提交
    chrome.tabs.create({ url: targetUrl }, (tab) => {
      chrome.storage.session.set({
        activeGrab: { requestId, targetUrl, tabId: tab.id }
      });
    });

    chrome.action.setBadgeText({ text: '…' });
    chrome.action.setBadgeBackgroundColor({ color: '#3b82f6' });
    sendResponse({ ok: true });
    return true;
  }

  // popup 触发"立即提交 cookie"
  if (msg.type === 'SUBMIT_COOKIE') {
    chrome.storage.session.get('activeGrab', async ({ activeGrab }) => {
      if (!activeGrab) { sendResponse({ ok: false, error: 'no active grab' }); return; }

      const { requestId, targetUrl, tabId } = activeGrab;

      try {
        // 注入 content script 收集 cookie
        const [result] = await chrome.scripting.executeScript({
          target: { tabId },
          func: collectCookies,
          args: [targetUrl]
        });

        const cookies = result.result;

        // 通过 WS 上报
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'COOKIE_RESULT', requestId, cookies }));
        }

        // 清理状态
        await chrome.storage.session.remove(['pendingRequest', 'activeGrab']);
        chrome.action.setBadgeText({ text: '✓' });
        chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });

        sendResponse({ ok: true, cookieCount: cookies.length });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
    });
    return true; // async
  }

  // popup 查询当前 WS 状态
  if (msg.type === 'GET_STATUS') {
    chrome.storage.session.get(['pendingRequest', 'activeGrab', 'wsUrl'], (data) => {
      sendResponse({
        connected: ws && ws.readyState === WebSocket.OPEN,
        wsUrl: data.wsUrl || null,
        pendingRequest: data.pendingRequest || null,
        activeGrab: data.activeGrab || null
      });
    });
    return true;
  }

  // popup 设置 WS 连接地址
  if (msg.type === 'CONNECT_WS') {
    const { url } = msg;
    // 安全校验：只允许 cloudide.woa.com 域名
    if (!ALLOWED_WS_ORIGINS.some(o => url.startsWith(o.replace(/\/$/, '')))) {
      // 动态允许同一 workspaceId 下的端口
      const isAllowed = /^wss:\/\/workspacej9jjy0b2zdgg0ebafo-\d+\.gz\.cloudide\.woa\.com/.test(url);
      if (!isAllowed) {
        sendResponse({ ok: false, error: '不允许连接到该地址' });
        return true;
      }
    }
    chrome.storage.session.set({ wsUrl: url });
    connectWS(url);
    sendResponse({ ok: true });
    return true;
  }
});

// ─── 从页面收集 cookie 的注入函数（在页面上下文执行）────────────────────────

function collectCookies(targetUrl) {
  // document.cookie 只能读到非 HttpOnly 的 cookie
  const fromDocument = document.cookie.split(';')
    .map(c => c.trim())
    .filter(Boolean)
    .map(c => {
      const idx = c.indexOf('=');
      return { name: c.slice(0, idx), value: c.slice(idx + 1), httpOnly: false };
    });

  return {
    url: location.href,
    documentCookies: fromDocument,
    // HttpOnly cookie 需要 background 通过 chrome.cookies API 获取
    note: 'HttpOnly cookies collected separately via chrome.cookies API'
  };
}

// ─── 启动时恢复 WS 连接 ──────────────────────────────────────────────────────

chrome.storage.session.get('wsUrl', ({ wsUrl }) => {
  if (wsUrl) connectWS(wsUrl);
});
